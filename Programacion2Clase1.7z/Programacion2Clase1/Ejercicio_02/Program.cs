﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Ejercicio_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 02";

            Console.Write("Ingrese un numero: ");
            String aux = Console.ReadLine();
            int valor;
            if (int.TryParse(aux, out valor))
            {
                if (valor > 0)
                {
                    double cuadrado = Math.Pow(valor, 2);
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("El cuadrado del valor es: {0}", cuadrado);
                    double cubo = Math.Pow(valor, 3);
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine("El cubo del valor es: {0}", cubo);
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("ERROR ¡Reingresar numero!");
                    Console.ReadLine();
                }
            }
        }
    }
}

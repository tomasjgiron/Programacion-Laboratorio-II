﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 01";
            int maximo = int.MinValue;
            int minimo = int.MaxValue;
            int contador = 0;
            float promedio;
            float acumulador = 0;
            int iteracion = 4;

            do
            {
                String aux = Console.ReadLine();
                int valor;
                if (int.TryParse(aux, out valor))
                {
                    if (valor > maximo)
                    {
                        maximo = valor;
                    }
                    if (valor < minimo)
                    {
                        minimo = valor;
                    }
                }
                contador++;
                acumulador += valor;
                iteracion--;
            } while (iteracion >= 0);

            promedio = acumulador / 5;
            Console.WriteLine("El minimo es: {0}",minimo);
            Console.WriteLine("El maximo es : {0}", maximo);
            Console.WriteLine("El promedio es : {0:#,###.00}", promedio);

            Console.ReadKey();


        }
    }
}
